//
//  SalesViewController.h
//  Sales
//
//  Created by feng on 15/7/31.
//  Copyright (c) 2015年 feng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SalesViewController : UIViewController

@end
